//
//  ViewController.swift
//  WeatherAppPretty
//
//  Created by robin on 2018-07-15.
//  Copyright © 2018 robin. All rights reserved.
//

import UIKit
import Alamofire            // 1. Import AlamoFire and SwiftyJson
import SwiftyJSON

import ChameleonFramework         // optional - used to make colors pretty

import CoreLocation               // TODO: Add location later


class ViewController: UIViewController, CLLocationManagerDelegate {

    // --------------------------------------------
    // MARK: User interface outlets
    // --------------------------------------------
    @IBOutlet weak var labelLocation: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var labelTemp: UILabel!
    @IBOutlet weak var imageWeatherIcon: UIImageView!
    @IBOutlet weak var labelHumidity: UILabel!
    @IBOutlet weak var labelVisibility: UILabel!
    @IBOutlet weak var labelRain: UILabel!
    @IBOutlet weak var labelStatus: UILabel!
    @IBOutlet weak var weatherIcon: UIImageView!
    
    
    // --------------------------------------------
    // TODO: url variables
    // --------------------------------------------
    let URL = "https://api.darksky.net/forecast/7a899b01fab1d4afcdfb5495b5e331f3"
    let LOCATION = "48.8566,2.3522"
    let PARAMS = "?exclude=minutely,hourly,daily,alerts,flags&units=ca"
    let locationManager : CLLocationManager = CLLocationManager()
    // --------------------------------------------
    // TODO: Add location variables
    // --------------------------------------------
    
    // put your location variables here
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // UI NONSENSE - Make a gradient background using Chameleon
        let colors:[UIColor] = [
            UIColor(hexString:"#F27121")!,
            UIColor(hexString:"#E94057")!,
            UIColor(hexString:"#8A2387")!
        ]
        view.backgroundColor = UIColor(gradientStyle:UIGradientStyle.topToBottom, withFrame:view.frame, andColors:colors)

        
        self.locationManager.delegate = self
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization()
        
        self.locationManager.startUpdatingLocation()

        
        // TODO: Get the current location
        //  do this later
        
        
        // TODO: Get the weather
        getWeather(url:URL)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func refreshWeather(_ sender: Any) {
        // TODO: Refresh the weather data.
        getWeather(url: URL)
        print("refresh weather button pushed")
    }

    
    @IBAction func changeLocation(_ sender: UIBarButtonItem) {
       let lat = locationManager.location?.coordinate.latitude
       let longi = locationManager.location?.coordinate.longitude
       let loc = "\(lat!),\(longi!)"
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // this function gets called every time the person's location changes
        print("location updated!")
        // get the last location in the array
        let i = locations.count - 1;
        let location = locations[i]
    }
    func getWeather(url:String) {
        // Build the URL:
        
        //let url = URL + LOCATION + PARAMS
      let url = "https://api.darksky.net/forecast/7a899b01fab1d4afcdfb5495b5e331f3/48.8566,2.3522?exclude=minutely,hourly,daily,alerts,flags&units=ca"
        print(url)
        
        
        
        Alamofire.request(url, method: .get, parameters: nil).responseJSON {
            
            (response) in
            
            if response.result.isSuccess {
                if let dataFromServer = response.data {
                    
        
                    do {
                        let json = try JSON(data: dataFromServer)
                        
                        // TODO: Parse the json response
                        print(json)
                        
                        // TODO: Display the results
                        let current = json["currently"].dictionaryValue
                        let date = current["time"]?.doubleValue
                        let status = current["summary"]?.stringValue
                        let temp = current["temperature"]?.doubleValue
                        var humidity = current["humidity"]?.doubleValue
                        var rainChance = current["precipProbability"]?.doubleValue
                        let windSpeed = current["windSpeed"]?.doubleValue
                      
                        //do any math conversions you need
                        
                        humidity = humidity! * 100
                        rainChance = rainChance! * 100
                        
                        //do a date conversion
                        // 1. convert from unix time to human readable time
                        var dateFromTimeStamp = Date(timeIntervalSince1970: date!)
                        
                        let dateFormatter = DateFormatter()
                        dateFormatter.timeZone = TimeZone(abbreviation: "EST")
                        
                        // 2. format the date  - Wednesday, July 25, 2018
                        dateFormatter.dateFormat = "EEEE, MMM d, yyyy"
                        let dayString = dateFormatter.string(from:dateFromTimeStamp)
                        
                        // update the navigation bar
                        self.title = dayString
                        
                        // 3. format the time - as 8:52pm
                        dateFormatter.dateFormat = "h:mm a"
                        let timeString = dateFormatter.string(from:dateFromTimeStamp)
                        
                        // update the label
                        self.labelDate.text = "\(timeString)"


                        
                        //printing in console
                        print("\(date)")
                        print("\(temp)")
                        print("\(status)")
                        print("\(humidity)")
                        print("\(rainChance)")
                        print("\(windSpeed)")
                        print("\(timeString)")
                        
                        //update user interface
                        
                        self.labelDate.text = "\(date)"
                        self.labelTemp.text = "\(temp!)"
                        self.labelHumidity.text = "\(String(format:"%.0f", humidity!))%"
                        self.labelVisibility.text = "\(windSpeed!) km/h"
                        self.labelRain.text = "\(String(format:"%.0f", rainChance!))%"
                        self.labelStatus.text = "\(status!)"
  
                    }
                    catch {
                        print("error")
                    }
                    
                }
                else {
                    print("Error when getting JSON from the response")
                }
            }
            else {
                // 6. You got an error while trying to connect to the API
                print("Error while fetching data from URL")
            }
            
        }
        

    }
    
    
    // --------------------------------------------
    // TODO: Add location
    // --------------------------------------------
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // this function gets called every time the person's location changes
        print("location updated!")

        
        
    }
    

}

