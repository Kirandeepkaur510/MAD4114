//
//  ViewController.swift
//  MyMap
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import MapKit   //APPLE'S MAP LIBRARY
import CoreLocation

class ViewController: UIViewController , CLLocationManagerDelegate , MKMapViewDelegate{
    
   //MARK outlet
    @IBOutlet weak var mapView: MKMapView!
    
    @IBOutlet weak var labelMap: UILabel!
    //Make a corelocation variable
    var manager : CLLocationManager!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
            /* loading map
            //1. COORDINATE : set the position of the center of map
            //CLlocationCoordinate
            //for toronto
            let coord = CLLocationCoordinate2DMake(43.6532, -79.3832)
        
            //2. SPAN : set the zoom level of the map
            //MKCoordinates
            //small no.  = go IN(closer)
            //large no. = go OUT(far away)
            let span = MKCoordinateSpanMake(0.02, 0.02)
        
            //3. REGION : create a region object of map
            let region = MKCoordinateRegionMake(coord, span)
        
            //4. do some nonsense to show the map on screen
            mapView.setRegion(region, animated: true)
            */
        
            //SHOW A POSITION USING PHONE'S LOCATION
            //1. set up your corelocation variable
            self.manager = CLLocationManager()
            self.manager.delegate = self
        
            //2. Tell ios how accurate you want the location to be
            self.manager.desiredAccuracy = kCLLocationAccuracyBest
        
            //3. Ask the user for permission to get their location
            self.manager.requestAlwaysAuthorization()
        
            //4. get the user's location
            self.manager.startUpdatingLocation()
        
            //UINonsense - Set up the map to show their location
            mapView.delegate = self as! MKMapViewDelegate
            mapView.mapType = MKMapType.standard
            mapView.showsUserLocation = true
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
  
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK  - corelocation related function
    //this functions gets run everytime the person moves.......
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //1. LOGIC: get the person's most recent location
        let i = locations.count - 1
      labelMap.text! = ("\(locations[i])")
        
        //2. UI Nonsenese : update the map to match
        //coordinate
        //let coord = CLLocationCoordinate2DMake(43.6532, -79.3832)
        let coord = mapView.userLocation.coordinate
        //span
        let span = MKCoordinateSpanMake(0.04, 0.04)
        //region
        let region = MKCoordinateRegionMake(coord, span)
        //ui garbage to show that
        self.mapView.setRegion(region, animated: true)
        
        
    }


}

