//
//  ViewController.swift
//  CoreData1
//
//  Created by MacStudent on 2018-07-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //1. create a variable that allows you to interact with coredata database
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let manageContext = appDelegate.persistentContainer.viewContext
        //2. create a row in table
        //2 a. which table do I wanna interct with
        let userEntity = NSEntityDescription.entity(forEntityName : "User" , in:manageContext)
        //2 b.
        //create a new user object
        let user = NSManagedObject(entity: userEntity! , insertInto: manageContext)
        // set the properties of the object
        user.setValue("Jigisha Patel" , forKey: "name")
        user.setValue("j@gmail.com" , forKey: "email")
        user.setValue(1 , forKey: "kids")
        //make a date
        let formatter = DateFormatter()
        formatter.dateFormat="yyyy-mm-dd"
        let date = formatter.date(from: "1985-12-13")
        user.setValue(date , forKey: "birthday")
        user.setValue("1", forKey: "id")
        //print(user)
        //3. save the row to database
        do{
           try manageContext.save()
        }
        catch{
        print("Problem saving in database......")
        }
        print("done saving in database")
        
        //4.a show
        //create a select * from user
        let userFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        //4.b run the sql
        do{
           let users = try manageContext.fetch(userFetch)
            print(users)
        }
        catch{
            print("Error while fetching results")
        }
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

