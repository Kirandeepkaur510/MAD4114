//
//  ViewController.swift
//  SaveVolume
//
//  Created by robin on 2017-11-08.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    //variables
   let defaults =  UserDefaults.standard
    
    @IBOutlet weak var volumeSlider: UISlider!
    override func viewDidLoad() {
        super.viewDidLoad()
      
        // Do any additional setup after loading the view, typically from a nib.
        let slider_value = defaults.double(forKey: "Slider")
        print(slider_value)
        volumeSlider.value = Float(slider_value)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sliderValueChange(_ sender: UISlider) {
        print(sender.value)
        defaults.set(sender.value, forKey: "Slider")
       
    }
}

